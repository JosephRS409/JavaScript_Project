# JavaScript_Project
Just a another game of Blackjack that I programmed in JavaScript.
